-- Install instructions:
	1. extract the contents of this folder into My Documents\DuckGame
	2. Done.


-- DGTASUI
	dgTasUI.exe can be found in the TAS Folder.
	It comes with tools that can load, edit and save dgtas files.
		
	-- Menu strip
		Fast Save - saves to to the last loaded file - [CTRL + S]
		Move Up - moves selected Frames up one step - [CTRL + UP]
		Move Down - moves selected Frames down one stop - [CTRL + DOWN]
		Edit - opens edit window that allows you to change values such as duration and what keys are down (can also double click frame)
		Remove - removes all selected frames - [Delete]
		Add New - Adds a new frame at the bottom and opens the edit window for it
		Insert after - Like Add New but places the frame after all selected frames - [Insert]
		Insert before - Like insert after but places it before the selected frames
		Insert Template - adds all frames from a dgtas file.
		Copy - copies all selected frames - [CTRL + C]
		Paste - pastes all copied frames, does now work between different sessions [CTRL + V]
	
		Open - Opens a dgtas file - [CTRL + O]
		Save As - Lets you save where ever you want - [CTRL + SHIFT + S]
		
	-- RNG value
		Basically sets the rng to a certain value that frame, if its 255 (max) the random number will always be the highest possible.
		I can justify directly set rng because the runs are based of randopm values before the run start,
		Its possible to get the rng you want before starting without having direct rng manipulation. 
		But that would require you to test up to 4294967296 random seeds. So its easier to just set it directly.
		
	-- Insert Template
		Lets you set all values in a template (ex: set right to true for all frames and jump to false).
		Each Input has its own box in which you can select one of the three options:
		
		KEEP SAME - doesnt modify the value for that Input so that its the same as in the template.
		TRUE - sets the values with that input to true (if JUMP is set to TRUE all frames in the template will have jump to true)
		FALSE - sets the values with that input to false (if RIGHT is set to FALSE all frames in the template will have right to false)

-- TAS Mod
	The mod will start playing a loaded dgtas file when any challenge level start.
	It also comes with a debug mode and a command.
	
	-- LoadTas console command
		The tasmod comes with a new command called LoadTas.
		Syntax: LoadTas <Tas Name>
		
		Loads a .dgtas file from the TAS directory to Duck Game.
		ex LoadTas OBSTACLE COURSE
		^^^^^^^^^^^^^^^^^^^^^^^^^ - will load the file "TAS\obstacle course.dgtas"
		
	-- UnLoadTas console commmand
		unloads the current loaded tas so that everything is normal.
	
	-- Debug Mode
		press F5 to enable debug mode. 
		It will say weather or not its enabled or disabled in console.
		When active it will load the dgtas file "TAS\debug.dgtas" at the start of the level so that you dont have to rewrite settas all the time.
		It will also show what frame its currently on next to the duck.
	
